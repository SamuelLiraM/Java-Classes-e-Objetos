
package objetoclasseq1;

public class ObjetoClasseQ1 {

    public static void main(String[] args) {
     
    }
    
}

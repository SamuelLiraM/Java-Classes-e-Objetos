
package objetoclasseq1;

import java.util.Scanner;
public class FaturaTeste {
    
    public static void main(String[] args) {
        
        Scanner sca = new Scanner(System.in);
        
        System.out.println("Digite o numero: ");
        String number = sca.nextLine();
        
        System.out.println("Qual a descrição do produto? ");
        String descricao = sca.nextLine();
        
        System.out.println("Qual a quantidade? ");
        int quantidade = sca.nextInt();
        
        System.out.println("Qual o preco? ");
        double preco = sca.nextDouble();
        
        Fatura p1 = new Fatura(quantidade, preco);
        
        p1.setNumero(number);
        p1.setDescricao(descricao);
        
        System.out.println("Numero:"+p1.getNumero()+
                "\nDescricao:"+p1.getDescricao()+
                "\nQuantidade:"+p1.getQuantidade()+
                "\nPreco:"+p1.getPreco());
        
        System.out.println("");
        
        System.out.println("O valor é: "+p1.getTotalFatura());
    }
}
